import Link from "next/link";
export const metadata = { title: "Log in | Portskillio" };
export default function Page() {
  return (
    <section className="mx-auto max-w-md px-5 py-24 text-center">
      <h1 className="font-display text-3xl font-extrabold">Log in</h1>
      <p className="mt-3 text-muted">Real accounts arrive in Phase 2. Until then, explore what each side will offer.</p>
      <div className="mt-8 grid gap-3">
        <Link href="/student" className="brand-bg rounded-full px-5 py-3 font-semibold text-white">I am a student</Link>
        <Link href="/recruiter" className="rounded-full border border-line px-5 py-3 font-semibold">I am a recruiter</Link>
      </div>
    </section>
  );
}
